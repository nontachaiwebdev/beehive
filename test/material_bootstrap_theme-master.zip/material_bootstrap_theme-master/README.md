# Material design for Bootstrap 3
This theme is a skin for Bootstrap, which means that can be used with any site built with the Bootstrap framework 3. With easy installation and customization thanks to the LESS/SASS files included and the custom themes colors ready to use. 
This skin is based on a material design and also extends the styles directly applied to Bootstrap files. There’s no overwritten rules or bloating CSS, making a lightweight skin as Boostrap is itself. 
#Word of the author
If you like my work, put likes. Also subscribe for updatings. It is important for me!

##Browsers
IE9+, Opera, Safari, Yandex browser, Chrome, Firefox, Mobile Safari, Android

## Demo
http://stas-melnikov.ru/material_bootstrap_theme/

#Help
If you liked this theme, please donate to me to steam of dollars. I very need your help. Thanks!

##Contact info
  * [my sait](http://stas-melnikov.ru)
  * [linkedIn](https://www.linkedin.com/in/melnik909)
  * [facebook](https://www.facebook.com/melnik909)
  * [googlePlus](https://plus.google.com/u/0/107045860611946174330/posts)

## License
MIT
